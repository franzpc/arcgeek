## Instalamos los paquetes si hace falta
if(!require("sf")) install.packages("sf")
if(!require("ggplot2")) install.packages("ggplot2")
if(!require("grid")) install.packages("grid")
if(!require("ggsn")) install.packages("ggsn")
if(!require("ggspatial")) install.packages("ggspatial")

## Activar la librerías
library(sf)
library(ggplot2)
library(ggsn)
library(ggspatial)
library(grid)

## Añadir capas vectoriales (shp)
Poblados <- st_read("D:/R/shp/Poblados.shp")
Rios <- st_read("D:/R/shp/Torrente.shp")
Vias <- st_read("D:/R/shp/Vias.shp")
Cobertura <- st_read("D:/R/shp/Cobertura.shp")

## Tipo de Geometría
st_geometry_type(Poblados)
st_geometry_type(Rios)
st_geometry_type(Vias)
st_geometry_type(Cobertura)

## Sistema de Coordenadas
st_crs(Poblados)
st_crs(Cobertura)

## Extensión espacial
st_bbox(Cobertura)

## Metadatos
Cobertura
Poblados
Vias

## Plot
plot(Cobertura)
plot(Rios)
plot(Vias)
plot(Poblados)



## Plot con ggplot2
ggplot() + 
  geom_sf(data = Vias, aes(color = Tipo)) + 
  ggtitle("Cobertura") + 
  coord_sf()

## Coordenadas GPS
GPS <- data.frame(longitude = c(690000, 693000), latitude = c(9533500, 9532500), name = c("Uno", "Oct"))


### Plotear varias capas
ggplot() + 
  geom_sf(data = Cobertura, aes(fill = Tipo)) + ###Agregar capas
  geom_sf(data = Vias, aes(color = Tipo)) + 
  geom_sf(data = Poblados, size = 3, color = "red") +  
  north(data = Vias, symbol = 12) + ### Agregar norte
  ggspatial::annotation_scale(location = "br") + #### agregar escala
  coord_sf(datum=st_crs(32717)) + ### mostrar en coordenadas planas
  geom_point(data = GPS, aes(x = longitude, y = latitude), size = 4, shape = 23, fill = "darkred") +
  geom_label(data = GPS, aes(x = longitude, y = latitude, label = name), size = 5) +
  ggtitle("Mi primer mapa en RStudio") + ### Título
  annotate(geom = "text", x = 689000, y = 9534000, label = "Mapa", fontface = "bold", color = "grey20", size = 3) + ## anotaciones
  annotate(geom = "text", x = 694000, y = 9534000, label = "@franzpc", fontface = "italic", color = "grey22", size = 3)
  

GPS <- data.frame(longitude = c(690000, 693000), latitude = c(9533500, 9532500), name = c("Uno", "Oct"))
                       

  coord_sf(datum=st_crs(32717))
  coord_sf(datum=target_crs)
  target_crs

coord_sf(xlim = c(-20, 45), ylim = c(30, 73), expand = FALSE)
lat_ts = mean(st_bbox(nc)[c(2,4)]) # latitude of true scale
eqc = st_transform(nc, paste0("+proj=eqc +lat_ts=", lat_ts))

ggplot() + st_geometry(data = Cobertura, axes = TRUE)
plot(st_geometry(Cobertura), axes = TRUE)

lat_ts = mean(st_bbox(Cobertura)[c(2,4)]) # latitude of true scale
eqc = st_transform(Cobertura, paste0("+proj=eqc +lat_ts=", lat_ts))
plot(st_geometry(eqc), axes = TRUE)
